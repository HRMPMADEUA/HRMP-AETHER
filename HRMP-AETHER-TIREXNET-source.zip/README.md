# TIREXNET Android — beta source

Persian RTL Android app project with login, private session storage, a subscription dashboard, traffic/expiry display, and automatic identification of Xray, WireGuard, and AmneziaWG profiles.

## API expected

- `POST /api/login` — accepts `{ "username": "...", "password": "..." }`; responds with a `token`.
- `GET /api/me` — returns `username` and `subscription` values (`username`, `status`, `usedTraffic`, `dataLimit`, `expire`).
- `POST /api/logout` — invalidates the bearer session.
- `GET /api/me/configs` — **must be added to the Cloudflare Worker**. It should authenticate the session token and return only configs belonging to the logged-in user's PasarGuard mapping, e.g. `{ "configs": [{ "name": "Profile 1", "config": "vless://..." }] }`. For WireGuard/AmneziaWG, `config` may contain the full `[Interface]` / `[Peer]` text. The app must not call PasarGuard admin endpoints directly.

## Important status

This is the first UI/API build. It can sign in, show account statistics, fetch/identify profiles, and display which of the requested three engine families a profile belongs to. **The actual VPN engines are not embedded in this beta yet**, so the profile-row button reports that engine integration is still required rather than pretending the device is connected. The next stage is embedding Xray, WireGuard, and AmneziaWG engines and wiring their Android VPN services.

## Build APK

Push the files to the `HRMP-AETHER` repository, then open GitHub **Actions → TIREXNET Android Build**. Download the artifact named `TIREXNET-APK`.
