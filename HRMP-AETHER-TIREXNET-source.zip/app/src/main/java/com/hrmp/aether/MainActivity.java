package com.hrmp.aether;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String API = "https://hrmp.hrmpdownloader.kdns.fr";
    private static final String PREFS = "tirexnet_private";
    private static final String TOKEN_KEY = "session_token";

    private static final int BG = Color.rgb(9, 13, 27);
    private static final int CARD = Color.rgb(20, 28, 48);
    private static final int CARD_LIGHT = Color.rgb(29, 40, 65);
    private static final int ACCENT = Color.rgb(47, 225, 190);
    private static final int WHITE = Color.rgb(244, 247, 255);
    private static final int MUTED = Color.rgb(159, 172, 198);
    private static final int RED = Color.rgb(255, 111, 128);
    private static final int GREEN = Color.rgb(72, 220, 155);

    private final ExecutorService network = Executors.newSingleThreadExecutor();
    private final List<ConfigItem> configs = new ArrayList<>();
    private SharedPreferences prefs;
    private String token = "";
    private String appUsername = "";
    private LinearLayout root;
    private LinearLayout configList;
    private EditText usernameInput;
    private EditText passwordInput;
    private TextView messageView;
    private TextView accountView;
    private TextView statusView;
    private TextView usedView;
    private TextView limitView;
    private TextView expiryView;
    private TextView configStatusView;
    private Button loginButton;
    private Button configButton;
    private ProgressBar progress;

    private static final class ConfigItem {
        final String name;
        final String protocol;
        final String raw;
        ConfigItem(String name, String protocol, String raw) {
            this.name = name;
            this.protocol = protocol;
            this.raw = raw;
        }
    }

    private static final class ApiResult {
        final int code;
        final String body;
        ApiResult(int code, String body) { this.code = code; this.body = body; }
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private GradientDrawable gradient(int first, int second, int radius) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{first, second});
        d.setCornerRadius(dp(radius));
        return d;
    }

    private LinearLayout.LayoutParams match(int h) {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(h));
    }

    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return l;
    }

    private TextView label(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        t.setTextDirection(View.TEXT_DIRECTION_RTL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private TextView centered(String value, int size, int color, boolean bold) {
        TextView t = label(value, size, color, bold);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    private Button button(String value, boolean primary) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextSize(14);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(primary ? BG : WHITE);
        b.setBackground(primary ? gradient(ACCENT, Color.rgb(83, 198, 255), 16) : rounded(CARD_LIGHT, 16));
        b.setPadding(dp(10), dp(6), dp(10), dp(6));
        return b;
    }

    private LinearLayout card() {
        LinearLayout c = vertical();
        c.setPadding(dp(16), dp(14), dp(16), dp(14));
        c.setBackground(rounded(CARD, 20));
        return c;
    }

    private void gap(LinearLayout parent, int h) {
        parent.addView(new TextView(this), match(h));
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        token = prefs.getString(TOKEN_KEY, "");
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        if (token == null || token.trim().isEmpty()) showLogin(); else showDashboard();
    }

    private void beginPage(String subtitle) {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        root = vertical();
        root.setPadding(dp(18), dp(18), dp(18), dp(24));
        scroll.addView(root, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout hero = vertical();
        hero.setGravity(Gravity.CENTER);
        hero.setPadding(dp(16), dp(18), dp(16), dp(18));
        hero.setBackground(gradient(Color.rgb(21, 75, 93), Color.rgb(31, 30, 77), 24));
        root.addView(hero, match(144));
        hero.addView(centered("TIREXNET", 29, WHITE, true), match(43));
        hero.addView(centered(subtitle, 14, ACCENT, true), match(30));
        hero.addView(centered("مدیریت ساده اشتراک و اتصال", 12, MUTED, false), match(27));
        gap(root, 15);
        setContentView(scroll);
    }

    private void showLogin() {
        beginPage("ورود به حساب کاربری");
        LinearLayout c = card();
        root.addView(c, match(316));
        c.addView(label("خوش اومدی 👋", 23, WHITE, true), match(40));
        c.addView(label("با اطلاعاتی که مدیر در اختیارت گذاشته وارد شو.", 12, MUTED, false), match(37));
        gap(c, 9);
        usernameInput = new EditText(this);
        usernameInput.setSingleLine(true);
        usernameInput.setTextSize(15);
        usernameInput.setTextColor(WHITE);
        usernameInput.setHintTextColor(MUTED);
        usernameInput.setHint("نام کاربری");
        usernameInput.setPadding(dp(14), dp(8), dp(14), dp(8));
        usernameInput.setBackground(rounded(CARD_LIGHT, 13));
        usernameInput.setTextDirection(View.TEXT_DIRECTION_LTR);
        usernameInput.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
        c.addView(usernameInput, match(51));
        gap(c, 11);
        passwordInput = new EditText(this);
        passwordInput.setSingleLine(true);
        passwordInput.setTextSize(15);
        passwordInput.setTextColor(WHITE);
        passwordInput.setHintTextColor(MUTED);
        passwordInput.setHint("رمز عبور");
        passwordInput.setInputType(129);
        passwordInput.setPadding(dp(14), dp(8), dp(14), dp(8));
        passwordInput.setBackground(rounded(CARD_LIGHT, 13));
        passwordInput.setTextDirection(View.TEXT_DIRECTION_LTR);
        passwordInput.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
        c.addView(passwordInput, match(51));
        gap(c, 13);
        loginButton = button("ورود امن", true);
        c.addView(loginButton, match(51));
        loginButton.setOnClickListener(v -> login());
        progress = new ProgressBar(this);
        progress.setVisibility(View.GONE);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(dp(32), dp(32));
        pp.gravity = Gravity.CENTER;
        pp.topMargin = dp(10);
        c.addView(progress, pp);

        messageView = centered("حساب کاربری باید توسط مدیر ساخته شده باشد.", 12, MUTED, false);
        LinearLayout.LayoutParams mlp = match(42);
        mlp.topMargin = dp(8);
        root.addView(messageView, mlp);
        gap(root, 10);
        LinearLayout info = card();
        root.addView(info, match(96));
        info.addView(label("🔐 ورود خصوصی", 15, ACCENT, true), match(28));
        info.addView(label("اطلاعات اشتراک فقط پس از ورود معتبر نمایش داده می‌شود.", 12, MUTED, false), match(42));
    }

    private void login() {
        final String user = usernameInput.getText().toString().trim();
        final String pass = passwordInput.getText().toString();
        if (user.isEmpty() || pass.isEmpty()) {
            setMessage("نام کاربری و رمز عبور را وارد کن.", RED);
            return;
        }
        busy(true);
        setMessage("در حال بررسی حساب…", MUTED);
        network.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("username", user);
                body.put("password", pass);
                ApiResult response = request("POST", "/api/login", body.toString(), null);
                JSONObject json = new JSONObject(response.body);
                String newToken = json.optString("token", "");
                if (response.code >= 200 && response.code < 300 && !newToken.isEmpty()) {
                    prefs.edit().putString(TOKEN_KEY, newToken).apply();
                    token = newToken;
                    appUsername = user;
                    runOnUiThread(this::showDashboard);
                } else {
                    String error = json.optString("error", "LOGIN_FAILED");
                    runOnUiThread(() -> {
                        busy(false);
                        setMessage(friendlyError(error), RED);
                    });
                }
            } catch (Exception e) {
                runOnUiThread(() -> {
                    busy(false);
                    setMessage("ارتباط برقرار نشد؛ اینترنت را بررسی کن.", RED);
                });
            }
        });
    }

    private void showDashboard() {
        beginPage("پنل اختصاصی تو");
        LinearLayout welcome = card();
        root.addView(welcome, match(88));
        welcome.addView(label("سلام، خوش اومدی 🌟", 20, WHITE, true), match(35));
        accountView = label("در حال دریافت اطلاعات…", 12, MUTED, false);
        welcome.addView(accountView, match(29));
        gap(root, 12);

        LinearLayout statusCard = card();
        root.addView(statusCard, match(91));
        statusCard.addView(label("وضعیت اشتراک", 12, MUTED, true), match(27));
        statusView = label("در حال بررسی…", 22, ACCENT, true);
        statusCard.addView(statusView, match(43));
        gap(root, 12);

        LinearLayout pair = new LinearLayout(this);
        pair.setOrientation(LinearLayout.HORIZONTAL);
        pair.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout left = card();
        LinearLayout right = card();
        pair.addView(left, new LinearLayout.LayoutParams(0, dp(101), 1));
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(0, dp(101), 1);
        rlp.leftMargin = dp(10);
        pair.addView(right, rlp);
        root.addView(pair, match(101));
        left.addView(label("مصرف‌شده", 12, MUTED, true), match(25));
        usedView = label("—", 18, WHITE, true);
        left.addView(usedView, match(43));
        right.addView(label("محدودیت حجم", 12, MUTED, true), match(25));
        limitView = label("—", 15, WHITE, true);
        right.addView(limitView, match(43));

        gap(root, 12);
        LinearLayout exp = card();
        root.addView(exp, match(74));
        exp.addView(label("تاریخ انقضا", 12, MUTED, true), match(24));
        expiryView = label("—", 16, WHITE, true);
        exp.addView(expiryView, match(33));

        gap(root, 16);
        LinearLayout subs = card();
        root.addView(subs, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        subs.addView(label("اشتراک‌های قابل استفاده", 18, WHITE, true), match(34));
        subs.addView(label("نوع هر کانفیگ خودکار تشخیص داده می‌شود؛ فقط Xray، WireGuard و AmneziaWG پشتیبانی می‌شوند.", 12, MUTED, false), match(49));
        configStatusView = label("در حال دریافت کانفیگ‌ها…", 12, ACCENT, true);
        subs.addView(configStatusView, match(43));
        configList = vertical();
        subs.addView(configList, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        configButton = button("دریافت دوباره اشتراک‌ها", true);
        LinearLayout.LayoutParams cbp = match(50);
        cbp.topMargin = dp(8);
        subs.addView(configButton, cbp);
        configButton.setOnClickListener(v -> refreshAll());

        gap(root, 10);
        Button refresh = button("به‌روزرسانی اطلاعات", false);
        root.addView(refresh, match(47));
        refresh.setOnClickListener(v -> refreshAll());
        gap(root, 8);
        Button logout = button("خروج از حساب", false);
        logout.setTextColor(RED);
        root.addView(logout, match(47));
        logout.setOnClickListener(v -> logout());
        root.addView(centered("TIREXNET • نسخه آزمایشی", 10, MUTED, false), match(35));
        refreshAll();
    }

    private void refreshAll() {
        if (configButton != null) {
            configButton.setEnabled(false);
            configButton.setText("در حال دریافت…");
        }
        network.execute(() -> {
            try {
                ApiResult profile = request("GET", "/api/me", null, token);
                if (profile.code == 401 || profile.code == 403) {
                    expireSession();
                    return;
                }
                if (profile.code < 200 || profile.code >= 300) throw new Exception("PROFILE_HTTP_" + profile.code);
                JSONObject json = new JSONObject(profile.body);
                JSONObject sub = json.optJSONObject("subscription");
                if (sub == null) sub = new JSONObject();
                appUsername = json.optString("username", appUsername);
                final String shownUser = sub.optString("username", "—");
                final String state = sub.optString("status", "نامشخص");
                final double used = sub.optDouble("usedTraffic", sub.optDouble("used_traffic", 0));
                final double limit = sub.optDouble("dataLimit", sub.optDouble("data_limit", 0));
                final String expiry = formatExpiry(sub.opt("expire"));
                runOnUiThread(() -> {
                    accountView.setText("حساب: " + appUsername + "  •  اشتراک: " + shownUser);
                    statusView.setText(persianStatus(state));
                    statusView.setTextColor(isActive(state) ? GREEN : RED);
                    usedView.setText(formatBytes(used));
                    limitView.setText(limit <= 0 ? "ثبت نشده / نامحدود" : formatBytes(limit));
                    expiryView.setText(expiry);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    statusView.setText("اطلاعات در دسترس نیست");
                    statusView.setTextColor(RED);
                });
            }

            try {
                ApiResult response = request("GET", "/api/me/configs", null, token);
                if (response.code == 401 || response.code == 403) {
                    expireSession();
                    return;
                }
                if (response.code >= 200 && response.code < 300) {
                    List<ConfigItem> found = parseConfigs(response.body);
                    synchronized (configs) { configs.clear(); configs.addAll(found); }
                    runOnUiThread(() -> showConfigs(found));
                } else {
                    String hint = response.code == 404
                            ? "سرویس دریافت کانفیگ هنوز در Worker فعال نشده است."
                            : "دریافت کانفیگ ناموفق بود (" + response.code + ").";
                    runOnUiThread(() -> showConfigError(hint));
                }
            } catch (Exception e) {
                runOnUiThread(() -> showConfigError("ارتباط با سرویس کانفیگ برقرار نشد."));
            }
        });
    }

    private void showConfigs(List<ConfigItem> found) {
        if (configButton == null || configList == null) return;
        configButton.setEnabled(true);
        configButton.setText("دریافت دوباره اشتراک‌ها");
        configList.removeAllViews();
        if (found.isEmpty()) {
            configStatusView.setText("کانفیگ سازگاری پیدا نشد.");
            return;
        }
        configStatusView.setText(found.size() + " کانفیگ دریافت شد");
        for (ConfigItem item : found) {
            LinearLayout row = vertical();
            row.setPadding(dp(12), dp(10), dp(12), dp(10));
            row.setBackground(rounded(CARD_LIGHT, 14));
            LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            rowLp.topMargin = dp(7);
            configList.addView(row, rowLp);
            row.addView(label(item.name, 14, WHITE, true), match(29));
            TextView protocol = label("موتور شناسایی‌شده: " + item.protocol, 12, ACCENT, true);
            row.addView(protocol, match(26));
            Button connect = button("آماده‌سازی اتصال", false);
            LinearLayout.LayoutParams c = match(42);
            c.topMargin = dp(5);
            row.addView(connect, c);
            connect.setOnClickListener(v -> Toast.makeText(this,
                    "کانفیگ " + item.protocol + " شناسایی شد؛ هسته اتصال واقعی هنوز باید به اپ متصل شود.",
                    Toast.LENGTH_LONG).show());
        }
    }

    private void showConfigError(String message) {
        if (configButton != null) {
            configButton.setEnabled(true);
            configButton.setText("تلاش دوباره برای دریافت");
        }
        if (configStatusView != null) configStatusView.setText(message);
        if (configList != null) configList.removeAllViews();
    }

    private List<ConfigItem> parseConfigs(String body) {
        List<ConfigItem> out = new ArrayList<>();
        if (body == null || body.trim().isEmpty()) return out;
        String payload = body.trim();
        try {
            if (payload.startsWith("{")) {
                JSONObject json = new JSONObject(payload);
                JSONArray items = json.optJSONArray("configs");
                if (items == null) items = json.optJSONArray("items");
                if (items != null) {
                    for (int i = 0; i < items.length(); i++) {
                        JSONObject o = items.optJSONObject(i);
                        if (o == null) continue;
                        String raw = first(o, "config", "uri", "link", "raw", "content");
                        if (raw.isEmpty()) continue;
                        String protocol = detectProtocol(raw);
                        if (protocol == null) continue;
                        String name = first(o, "name", "remark", "tag");
                        if (name.isEmpty()) name = protocol + " " + (i + 1);
                        out.add(new ConfigItem(name, protocol, raw));
                    }
                    return out;
                }
                payload = first(json, "content", "subscription", "config", "data");
            }
        } catch (Exception ignored) { }
        parseText(out, payload);
        if (out.isEmpty() && !payload.isEmpty()) {
            try {
                String decoded = new String(Base64.decode(payload.replaceAll("\\s+", ""), Base64.DEFAULT), StandardCharsets.UTF_8).trim();
                if (!decoded.equals(payload)) parseText(out, decoded);
            } catch (Exception ignored) { }
        }
        return out;
    }

    private void parseText(List<ConfigItem> out, String value) {
        if (value == null || value.trim().isEmpty()) return;
        String text = value.trim();
        String detected = detectProtocol(text);
        if ("WireGuard".equals(detected) || "AmneziaWG".equals(detected)) {
            out.add(new ConfigItem(detected + " 1", detected, text));
            return;
        }
        int count = 1;
        for (String line : text.split("\\r?\\n")) {
            String uri = line.trim();
            if (uri.isEmpty() || uri.startsWith("#")) continue;
            String protocol = detectProtocol(uri);
            if (protocol != null) out.add(new ConfigItem(protocol + " " + count++, protocol, uri));
        }
    }

    private String detectProtocol(String input) {
        if (input == null) return null;
        String s = input.trim().toLowerCase(Locale.ROOT);
        if (s.startsWith("vless://") || s.startsWith("vmess://") || s.startsWith("trojan://")
                || s.startsWith("ss://")) return "Xray";
        if (s.startsWith("amneziawg://") || s.startsWith("awg://")) return "AmneziaWG";
        if (s.startsWith("wireguard://") || s.startsWith("wg://")) return "WireGuard";
        if (s.contains("[interface]") && s.contains("[peer]")) {
            if (s.matches("(?s).*(\\b(jc|jmin|jmax|s1|s2|h1|h2|h3|h4)\\s*=).*")) return "AmneziaWG";
            return "WireGuard";
        }
        return null;
    }

    private String first(JSONObject o, String... keys) {
        for (String k : keys) {
            String v = o.optString(k, "").trim();
            if (!v.isEmpty() && !"null".equalsIgnoreCase(v)) return v;
        }
        return "";
    }

    private String formatBytes(double bytes) {
        if (bytes <= 0) return "۰ بایت";
        String[] units = {"بایت", "کیلوبایت", "مگابایت", "گیگابایت", "ترابایت"};
        double amount = bytes;
        int unit = 0;
        while (amount >= 1024 && unit < units.length - 1) { amount /= 1024; unit++; }
        return String.format(Locale.US, "%.2f %s", amount, units[unit]);
    }

    private String formatExpiry(Object raw) {
        if (raw == null || JSONObject.NULL.equals(raw)) return "در پنل ثبت نشده";
        if (raw instanceof Number) {
            long ms = ((Number) raw).longValue();
            if (ms > 0 && ms < 100000000000L) ms *= 1000L;
            return ms > 0 ? new SimpleDateFormat("yyyy/MM/dd", Locale.getDefault()).format(new Date(ms)) : "در پنل ثبت نشده";
        }
        String s = String.valueOf(raw).trim();
        if (s.isEmpty() || "null".equalsIgnoreCase(s)) return "در پنل ثبت نشده";
        if (s.length() >= 10 && s.charAt(4) == '-' && s.charAt(7) == '-') return s.substring(0, 10).replace('-', '/');
        return s;
    }

    private String persianStatus(String s) {
        String v = s == null ? "" : s.trim().toLowerCase(Locale.ROOT);
        if ("active".equals(v) || "enabled".equals(v) || "on".equals(v)) return "● فعال";
        if ("expired".equals(v)) return "● منقضی شده";
        if ("disabled".equals(v) || "inactive".equals(v) || "limited".equals(v)) return "● غیرفعال";
        return s == null || s.trim().isEmpty() ? "نامشخص" : s;
    }

    private boolean isActive(String s) {
        if (s == null) return false;
        String v = s.trim().toLowerCase(Locale.ROOT);
        return "active".equals(v) || "enabled".equals(v) || "on".equals(v);
    }

    private ApiResult request(String method, String path, String body, String bearer) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(API + path).openConnection();
        c.setRequestMethod(method);
        c.setConnectTimeout(12000);
        c.setReadTimeout(15000);
        c.setUseCaches(false);
        c.setRequestProperty("Accept", "application/json, text/plain, */*");
        if (bearer != null && !bearer.isEmpty()) c.setRequestProperty("Authorization", "Bearer " + bearer);
        if (body != null) {
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        }
        try {
            if (body != null) {
                byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
                c.setFixedLengthStreamingMode(bytes.length);
                try (OutputStream out = c.getOutputStream()) { out.write(bytes); }
            }
            int code = c.getResponseCode();
            InputStream stream = code >= 400 ? c.getErrorStream() : c.getInputStream();
            String text = "";
            if (stream != null) {
                try (InputStream in = stream; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                    byte[] buffer = new byte[4096];
                    int n;
                    while ((n = in.read(buffer)) != -1) {
                        out.write(buffer, 0, n);
                        if (out.size() > 2 * 1024 * 1024) throw new Exception("Server response too large");
                    }
                    text = out.toString("UTF-8");
                }
            }
            return new ApiResult(code, text);
        } finally { c.disconnect(); }
    }

    private String friendlyError(String code) {
        if ("INVALID_CREDENTIALS".equals(code)) return "نام کاربری یا رمز عبور اشتباه است.";
        if ("ACCOUNT_DISABLED".equals(code)) return "این حساب غیرفعال شده است.";
        if ("RATE_LIMITED".equals(code)) return "تعداد تلاش‌ها زیاد است؛ بعداً دوباره امتحان کن.";
        return "ورود انجام نشد؛ اطلاعات را بررسی کن.";
    }

    private void setMessage(String text, int color) {
        if (messageView != null) { messageView.setText(text); messageView.setTextColor(color); }
        else Toast.makeText(this, text, Toast.LENGTH_LONG).show();
    }

    private void busy(boolean value) {
        if (loginButton != null) { loginButton.setEnabled(!value); loginButton.setText(value ? "در حال ورود…" : "ورود امن"); }
        if (progress != null) progress.setVisibility(value ? View.VISIBLE : View.GONE);
        if (usernameInput != null) usernameInput.setEnabled(!value);
        if (passwordInput != null) passwordInput.setEnabled(!value);
    }

    private void expireSession() {
        prefs.edit().remove(TOKEN_KEY).apply();
        token = "";
        runOnUiThread(() -> {
            Toast.makeText(this, "نشست ورود منقضی شده؛ دوباره وارد شو.", Toast.LENGTH_LONG).show();
            showLogin();
        });
    }

    private void logout() {
        final String old = token;
        token = "";
        prefs.edit().remove(TOKEN_KEY).apply();
        network.execute(() -> {
            try { request("POST", "/api/logout", "{}", old); } catch (Exception ignored) { }
            runOnUiThread(this::showLogin);
        });
    }
}
